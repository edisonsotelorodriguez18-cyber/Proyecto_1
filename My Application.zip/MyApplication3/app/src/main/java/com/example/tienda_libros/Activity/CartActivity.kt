package com.example.tienda_libros.Activity

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.example.tienda_libros.R
import com.example.tienda_libros.Adapter.CartAdapter
import com.example.tienda_libros.Database.Cartitem
import com.example.tienda_libros.Database.DatabaseHelper

class CartActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var cartAdapter: CartAdapter
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var tvTotal: TextView
    private lateinit var btnCheckout: MaterialButton
    private var cartItems = mutableListOf<Cartitem>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cart)

        dbHelper = DatabaseHelper(this)
        recyclerView = findViewById(R.id.recycler_view_cart)
        tvTotal = findViewById(R.id.tv_cart_total)
        btnCheckout = findViewById(R.id.btn_checkout)

        setupRecyclerView()
        loadCart()

        btnCheckout.setOnClickListener {
            if (cartItems.isNotEmpty()) {
                // Procesar compra
                dbHelper.clearCart()
                finish()
            }
        }
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        cartAdapter = CartAdapter(
            cartItems,
            onQuantityChanged = { cartItem, newQuantity ->
                dbHelper.updateCartItemQuantity(cartItem.productId, newQuantity)
                loadCart()
            },
            onRemove = { cartItem ->
                dbHelper.removeFromCart(cartItem.productId)
                loadCart()
            }
        )
        recyclerView.adapter = cartAdapter
    }

    private fun loadCart() {
        cartItems = dbHelper.getCartItems().toMutableList()
        cartAdapter.notifyDataSetChanged()

        val total = dbHelper.getCartTotal()
        tvTotal.text = "Total: $$total"
    }
}