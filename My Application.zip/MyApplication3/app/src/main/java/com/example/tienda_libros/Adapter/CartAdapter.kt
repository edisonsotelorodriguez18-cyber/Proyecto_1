package com.example.tienda_libros.Adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import android.widget.TextView
import com.example.tienda_libros.Database.Cartitem
import com.example.tienda_libros.R

class CartAdapter(
    private val cartItems: MutableList<Cartitem>,
    private val onQuantityChanged: (Cartitem, Int) -> Unit,
    private val onRemove: (Cartitem) -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    inner class CartViewHolder(itemView: ViewGroup) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tv_cart_name)
        private val tvPrice: TextView = itemView.findViewById(R.id.tv_cart_price)
        private val tvQuantity: TextView = itemView.findViewById(R.id.tv_cart_quantity)
        private val tvSubtotal: TextView = itemView.findViewById(R.id.tv_cart_subtotal)
        private val btnIncrease: MaterialButton = itemView.findViewById(R.id.btn_increase)
        private val btnDecrease: MaterialButton = itemView.findViewById(R.id.btn_decrease)
        private val btnRemove: MaterialButton = itemView.findViewById(R.id.btn_remove)

        fun bind(cartItem: Cartitem) {
            tvName.text = cartItem.name
            tvPrice.text = "$${cartItem.price}"
            tvQuantity.text = cartItem.quantity.toString()
            tvSubtotal.text = "$${cartItem.subtotal}"

            btnIncrease.setOnClickListener {
                onQuantityChanged(cartItem, cartItem.quantity + 1)
            }

            btnDecrease.setOnClickListener {
                if (cartItem.quantity > 1) {
                    onQuantityChanged(cartItem, cartItem.quantity - 1)
                }
            }

            btnRemove.setOnClickListener {
                onRemove(cartItem)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.cart_item, parent, false) as ViewGroup
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        holder.bind(cartItems[position])
    }

    override fun getItemCount() = cartItems.size
}