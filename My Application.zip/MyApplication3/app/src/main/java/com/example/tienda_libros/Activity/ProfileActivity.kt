package com.example.tienda_libros.Activity

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.tienda_libros.R
import androidx.cardview.widget.CardView
import com.example.tienda_libros.Activity.WelcomeActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.imageview.ShapeableImageView

class ProfileActivity : AppCompatActivity() {

    private lateinit var ivProfileImage: ShapeableImageView
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var cvPersonalInfo: CardView
    private lateinit var cvOrderHistory: CardView
    private lateinit var cvAddresses: CardView
    private lateinit var cvPaymentMethods: CardView
    private lateinit var cvSettings: CardView
    private lateinit var btnEditProfile: MaterialButton
    private lateinit var btnLogout: MaterialButton
    private lateinit var btnDetails: MaterialButton
    private lateinit var btnList: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        initViews()
        setupClickListeners()
        loadUserData()
    }

    private fun initViews() {
        ivProfileImage = findViewById(R.id.iv_profile_image)
        tvUserName = findViewById(R.id.tv_user_name)
        tvUserEmail = findViewById(R.id.tv_user_email)
        cvPersonalInfo = findViewById(R.id.cv_personal_info)
        cvOrderHistory = findViewById(R.id.cv_order_history)
        cvAddresses = findViewById(R.id.cv_addresses)
        cvPaymentMethods = findViewById(R.id.cv_payment_methods)
        cvSettings = findViewById(R.id.cv_settings)
        btnEditProfile = findViewById(R.id.btn_edit_profile)
        btnLogout = findViewById(R.id.btn_logout)
        btnDetails = findViewById(R.id.btn_details)
    }

    private fun setupClickListeners() {
        cvPersonalInfo.setOnClickListener {
            val intent = Intent(this, ProductListActivity::class.java)
            startActivity(intent)
        }

        cvOrderHistory.setOnClickListener {
            val intent = Intent(this, CartActivity::class.java)
            startActivity(intent)
        }
        cvPersonalInfo.setOnClickListener {
            val intent = Intent(this, ProductDetailActivity::class.java)
            startActivity(intent)
        }
        cvPersonalInfo.setOnClickListener {
            val intent = Intent(this, ProductListActivity::class.java)
            startActivity(intent)
        }

        cvAddresses.setOnClickListener {
            // Navegar a direcciones
        }

        cvPaymentMethods.setOnClickListener {
            // Navegar a métodos de pago
        }

        cvSettings.setOnClickListener {
            // Navegar a configuración
        }

        btnEditProfile.setOnClickListener {
            // Navegar a editar perfil
        }

        btnLogout.setOnClickListener {
            performLogout()
        }
    }

    private fun loadUserData() {
        // Cargar datos del usuario (desde SharedPreferences, API, etc.)
        tvUserName.text = "Juan Pérez"
        tvUserEmail.text = "juan.perez@email.com"
    }

    private fun performLogout() {
        // Limpiar datos de sesión
        startActivity(Intent(this, WelcomeActivity::class.java))
        finishAffinity() // Cerrar todas las actividades
    }
}