package com.example.tienda_libros.Database

import android.content.Context
import android.database.sqlite.SQLiteOpenHelper
import android.database.sqlite.SQLiteDatabase
import android.content.ContentValues

class DatabaseHelper (context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
    companion object {
        private const val DATABASE_NAME = "tienda_libros.db"
        private const val DATABASE_VERSION = 1

        private const val TABLE_PRODUCTS = "products"
        private const val PRODUCT_ID = "id"
        private const val PRODUCT_NAME = "name"
        private const val PRODUCT_DESCRIPTION = "description"
        private const val PRODUCT_PRICE = "price"
        private const val PRODUCT_STOCK = "stock"
        private const val PRODUCT_IMAGE = "image_url"
        private const val PRODUCT_CATEGORY = "category"

        private const val TABLE_CART = "cart"
        private const val CART_ID = "id"
        private const val CART_PRODUCT_ID = "product_id"
        private const val CART_QUANTITY = "quantity"

        private const val TABLE_ORDERS = "orders"
        private const val ORDER_ID = "id"
        private const val ORDER_DATA = "data"
        private const val ORDER_TOTAL = "total"
        private const val ORDER_STATUS = "status"
    }

    override fun onCreate(db: SQLiteDatabase) {

        val createProductsTable = """
            CREATE TABLE $TABLE_PRODUCTS (
                $PRODUCT_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $PRODUCT_NAME TEXT NOT NULL,
                $PRODUCT_DESCRIPTION TEXT,
                $PRODUCT_PRICE REAL NOT NULL,
                $PRODUCT_STOCK INTEGER NOT NULL,
                $PRODUCT_IMAGE TEXT,
                $PRODUCT_CATEGORY TEXT
            )
        """
        db.execSQL(createProductsTable)

        val createCartTable = """
            CREATE TABLE $TABLE_CART (
                $CART_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $CART_PRODUCT_ID INTEGER NOT NULL,
                $CART_QUANTITY INTEGER NOT NULL DEFAULT 1,
                FOREIGN KEY($CART_PRODUCT_ID) REFERENCES $TABLE_PRODUCTS($PRODUCT_ID)
            )
            """
        db.execSQL(createCartTable)

        val createOrdersTable = """
            CREATE TABLE $TABLE_ORDERS (
                $ORDER_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $ORDER_DATA TEXT NOT NULL,
                $ORDER_TOTAL REAL NOT NULL,
                $ORDER_STATUS TEXT NOT NULL
            )
        """
        db.execSQL(createOrdersTable)

        insertInitialProducts(db)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_PRODUCTS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_CART")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_ORDERS")
        onCreate(db)
    }

    private fun insertInitialProducts(db: SQLiteDatabase) {
        val products = listOf(
            Product(1, "Hunger Games box set, Deluxe Edition", "Paquete de libros de la saga de Hunger Games, donde podrás tener los libros con un diseño delujo.", 350.000, 1, "https://images.cdn1.buscalibre.com/fit-in/360x360/14/1b/141b21e66e6210be264625a77bc22719.jpg", "Box Set"),
        )

        for (product in products) {
            val values = ContentValues().apply {
                put(PRODUCT_NAME, product.name)
                put(PRODUCT_DESCRIPTION, product.description)
                put(PRODUCT_PRICE, product.price)
                put(PRODUCT_STOCK, product.stock)
                put(PRODUCT_IMAGE, product.imageUrl)
                put(PRODUCT_CATEGORY, product.category)
            }
            db.insert(TABLE_PRODUCTS, null, values)

        }
    }

    fun getAllProducts(): List<Product> {
        val products = mutableListOf<Product>()
        val db = readableDatabase
        val cursor = db.query(TABLE_PRODUCTS, null, null, null, null, null, null)

        with(cursor) {
            while (moveToNext()) {
                val product = Product(
                    id = getInt(getColumnIndexOrThrow(PRODUCT_ID)),
                    name = getString(getColumnIndexOrThrow(PRODUCT_NAME)),
                    description = getString(getColumnIndexOrThrow(PRODUCT_DESCRIPTION)),
                    price = getDouble(getColumnIndexOrThrow(PRODUCT_PRICE)),
                    stock = getInt(getColumnIndexOrThrow(PRODUCT_STOCK)),
                    imageUrl = getString(getColumnIndexOrThrow(PRODUCT_IMAGE)),
                    category = getString(getColumnIndexOrThrow(PRODUCT_CATEGORY))
                )
                products.add(product)
            }
            close()
        }
        return products
    }

    fun getProductById(productId: Int): Product? {
        val db = readableDatabase
        val cursor = db.query(
            TABLE_PRODUCTS,
            null,
            "$PRODUCT_ID = ?",
            arrayOf(productId.toString()),
            null,
            null,
            null
        )

        var product: Product? = null
        with(cursor) {
            if (moveToFirst()) {
                product = Product(
                    id = getInt(getColumnIndexOrThrow(PRODUCT_ID)),
                    name = getString(getColumnIndexOrThrow(PRODUCT_NAME)),
                    description = getString(getColumnIndexOrThrow(PRODUCT_DESCRIPTION)),
                    price = getDouble(getColumnIndexOrThrow(PRODUCT_PRICE)),
                    stock = getInt(getColumnIndexOrThrow(PRODUCT_STOCK)),
                    imageUrl = getString(getColumnIndexOrThrow(PRODUCT_IMAGE)),
                    category = getString(getColumnIndexOrThrow(PRODUCT_CATEGORY))
                )
            }
            close()
        }
        return product
    }

    fun addProduct(product: Product): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(PRODUCT_NAME, product.name)
            put(PRODUCT_DESCRIPTION, product.description)
            put(PRODUCT_PRICE, product.price)
            put(PRODUCT_STOCK, product.stock)
            put(PRODUCT_IMAGE, product.imageUrl)
            put(PRODUCT_CATEGORY, product.category)
        }
        val result = db.insert(TABLE_PRODUCTS, null, values)
        db.close()
        return result != -1L
    }

    fun updateProduct(product: Product): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(PRODUCT_NAME, product.name)
            put(PRODUCT_DESCRIPTION, product.description)
            put(PRODUCT_PRICE, product.price)
            put(PRODUCT_STOCK, product.stock)
            put(PRODUCT_IMAGE, product.imageUrl)
            put(PRODUCT_CATEGORY, product.category)
        }
        val result = db.update(TABLE_PRODUCTS, values, "$PRODUCT_ID = ?", arrayOf(product.id.toString()))
        db.close()
        return result > 0
    }

    fun deleteProduct(productId: Int): Boolean {
        val db = writableDatabase
        val result = db.delete(TABLE_PRODUCTS, "$PRODUCT_ID = ?", arrayOf(productId.toString()))
        db.close()
        return result > 0
    }

    // Operaciones del Carrito

    fun addToCart(cartItem: Cartitem): Boolean {
        val db = writableDatabase

        // Verificar si el producto ya existe en el carrito
        val cursor = db.query(TABLE_CART, null, "$CART_PRODUCT_ID = ?", arrayOf(cartItem.productId.toString()), null, null, null)

        val result = if (cursor.moveToFirst()) {
            // Actualizar cantidad
            val currentQuantity = cursor.getInt(cursor.getColumnIndexOrThrow(CART_QUANTITY))
            val values = ContentValues().apply {
                put(CART_QUANTITY, currentQuantity + cartItem.quantity)
            }
            db.update(TABLE_CART, values, "$CART_PRODUCT_ID = ?", arrayOf(cartItem.productId.toString()))
        } else {
            // Insertar nuevo item
            val values = ContentValues().apply {
                put(CART_PRODUCT_ID, cartItem.productId)
                put(CART_QUANTITY, cartItem.quantity)
            }
            db.insert(TABLE_CART, null, values)
        }

        cursor.close()
        db.close()
        return result != -1L
    }

    fun getCartItems(): List<Cartitem> {
        val cartItems = mutableListOf<Cartitem>()
        val db = readableDatabase

        val cursor = db.rawQuery("""
            SELECT c.id, c.product_id, p.name, p.price, c.quantity, p.image_url, 
                   (p.price * c.quantity) as subtotal
            FROM $TABLE_CART c
            JOIN $TABLE_PRODUCTS p ON c.product_id = p.id
        """.trimIndent(), null)

        with(cursor) {
            while (moveToNext()) {
                val cartItem = Cartitem(
                    id = getInt(getColumnIndexOrThrow("id")),
                    productId = getInt(getColumnIndexOrThrow("product_id")),
                    name = getString(getColumnIndexOrThrow("name")),
                    price = getDouble(getColumnIndexOrThrow("price")),
                    quantity = getInt(getColumnIndexOrThrow("quantity")),
                    imageUrl = getString(getColumnIndexOrThrow("image_url")),
                    subtotal = getDouble(getColumnIndexOrThrow("subtotal"))
                )
                cartItems.add(cartItem)
            }
            close()
        }
        return cartItems
    }

    fun updateCartItemQuantity(productId: Int, quantity: Int): Boolean {
        val db = writableDatabase
        val values = ContentValues().apply {
            put(CART_QUANTITY, quantity)
        }
        val result = db.update(TABLE_CART, values, "$CART_PRODUCT_ID = ?", arrayOf(productId.toString()))
        db.close()
        return result > 0
    }

    fun removeFromCart(productId: Int): Boolean {
        val db = writableDatabase
        val result = db.delete(TABLE_CART, "$CART_PRODUCT_ID = ?", arrayOf(productId.toString()))
        db.close()
        return result > 0
    }

    fun clearCart(): Boolean {
        val db = writableDatabase
        db.delete(TABLE_CART, null, null)
        db.close()
        return true
    }

    fun getCartTotal(): Double {
        val db = readableDatabase
        val cursor = db.rawQuery(
            """
            SELECT SUM(p.price * c.quantity) as total
            FROM $TABLE_CART c
            JOIN $TABLE_PRODUCTS p ON c.product_id = p.id
        """.trimIndent(), null
        )

        var total = 0.0
        with(cursor) {
            if (moveToFirst()) {
                total = getDouble(getColumnIndexOrThrow("total"))
            }
            close()
        }
        return total

    }
}