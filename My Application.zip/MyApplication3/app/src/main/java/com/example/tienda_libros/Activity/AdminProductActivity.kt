package com.example.tienda_libros.Activity

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.example.tienda_libros.R
import com.example.tienda_libros.Database.DatabaseHelper
import com.example.tienda_libros.Database.Product

class AdminProductActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var btnAddProduct: MaterialButton
    private var products = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_product)

        dbHelper = DatabaseHelper(this)
        recyclerView = findViewById(R.id.recycler_view_admin_products)
        btnAddProduct = findViewById(R.id.btn_add_product)

        setupRecyclerView()
        loadProducts()

        btnAddProduct.setOnClickListener {
            showAddProductDialog()
        }
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        // Aquí usarías el ProductAdapter con opciones de editar y eliminar
    }

    private fun loadProducts() {
        products = dbHelper.getAllProducts().toMutableList()
    }

    private fun showAddProductDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Agregar Producto")

        // Crear layout personalizado para el diálogo
        val layout = android.widget.LinearLayout(this)
        layout.orientation = android.widget.LinearLayout.VERTICAL
        layout.setPadding(20, 20, 20, 20)

        val etName = TextInputEditText(this)
        etName.hint = "Nombre"
        layout.addView(etName)

        val etPrice = TextInputEditText(this)
        etPrice.hint = "Precio"
        etPrice.inputType = android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        layout.addView(etPrice)

        val etStock = TextInputEditText(this)
        etStock.hint = "Stock"
        etStock.inputType = android.text.InputType.TYPE_CLASS_NUMBER
        layout.addView(etStock)

        builder.setView(layout)
        builder.setPositiveButton("Agregar") { _, _ ->
            val name = etName.text.toString()
            val price = etPrice.text.toString().toDoubleOrNull() ?: 0.0
            val stock = etStock.text.toString().toIntOrNull() ?: 0

            if (name.isNotEmpty() && price > 0 && stock > 0) {
                val product = Product(name = name, price = price, stock = stock)
                if (dbHelper.addProduct(product)) {
                    Toast.makeText(this, "Producto agregado", Toast.LENGTH_SHORT).show()
                    loadProducts()
                }
            }
        }
        builder.setNegativeButton("Cancelar", null)
        builder.show()
    }
}