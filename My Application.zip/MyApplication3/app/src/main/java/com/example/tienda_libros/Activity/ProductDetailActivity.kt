package com.example.tienda_libros.Activity

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.example.tienda_libros.R
import com.example.tienda_libros.Database.Cartitem
import com.example.tienda_libros.Database.DatabaseHelper
import com.example.tienda_libros.Database.Product

class ProductDetailActivity : AppCompatActivity() {

    private lateinit var ivProductImage: ImageView
    private lateinit var tvProductName: TextView
    private lateinit var tvProductDescription: TextView
    private lateinit var tvProductPrice: TextView
    private lateinit var tvProductStock: TextView
    private lateinit var tvProductCategory: TextView
    private lateinit var etQuantity: TextInputEditText
    private lateinit var btnAddToCart: MaterialButton
    private lateinit var btnDecreaseQuantity: MaterialButton
    private lateinit var btnIncreaseQuantity: MaterialButton
    private lateinit var btnBack: MaterialButton

    private lateinit var dbHelper: DatabaseHelper
    private var product: Product? = null
    private var selectedQuantity: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_detail)

        dbHelper = DatabaseHelper(this)

        // Inicializar vistas
        initViews()

        // Obtener el ID del producto del Intent
        val productId = intent.getIntExtra("product_id", -1)

        if (productId != -1) {
            loadProductDetails(productId)
        } else {
            Toast.makeText(this, "Error: Producto no encontrado", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun initViews() {
        ivProductImage = findViewById(R.id.iv_product_detail_image)
        tvProductName = findViewById(R.id.tv_product_detail_name)
        tvProductDescription = findViewById(R.id.tv_product_detail_description)
        tvProductPrice = findViewById(R.id.tv_product_detail_price)
        tvProductStock = findViewById(R.id.tv_product_detail_stock)
        tvProductCategory = findViewById(R.id.tv_product_detail_category)
        etQuantity = findViewById(R.id.et_quantity)
        btnAddToCart = findViewById(R.id.btn_add_to_cart_detail)
        btnDecreaseQuantity = findViewById(R.id.btn_decrease_quantity)
        btnIncreaseQuantity = findViewById(R.id.btn_increase_quantity)
        btnBack = findViewById(R.id.btn_back)

        setupClickListeners()
    }

    private fun setupClickListeners() {
        btnAddToCart.setOnClickListener {
            addToCart()
        }

        btnDecreaseQuantity.setOnClickListener {
            if (selectedQuantity > 1) {
                selectedQuantity--
                updateQuantityDisplay()
            }
        }

        btnIncreaseQuantity.setOnClickListener {
            if (product != null && selectedQuantity < product!!.stock) {
                selectedQuantity++
                updateQuantityDisplay()
            } else {
                Toast.makeText(
                    this,
                    "No hay más stock disponible",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        btnBack.setOnClickListener {
            finish()
        }
    }

    private fun loadProductDetails(productId: Int) {
        product = dbHelper.getProductById(productId)

        if (product != null) {
            displayProductDetails(product!!)
        } else {
            Toast.makeText(this, "Producto no encontrado en la base de datos", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun displayProductDetails(product: Product) {
        // Cargar imagen con Glide
        Glide.with(this)
            .load(product.imageUrl)
            .placeholder(R.drawable.placeholder)
            .error(R.drawable.error)
            .centerCrop()
            .into(ivProductImage)

        // Mostrar información del producto
        tvProductName.text = product.name
        tvProductDescription.text = product.description
        tvProductPrice.text = "Precio: $$${String.format("%.2f", product.price)}"
        tvProductStock.text = "Stock disponible: ${product.stock} unidades"
        tvProductCategory.text = "Categoría: ${product.category}"

        // Inicializar cantidad
        selectedQuantity = 1
        updateQuantityDisplay()

        // Habilitar/deshabilitar botón agregar al carrito según stock
        btnAddToCart.isEnabled = product.stock > 0
    }

    private fun updateQuantityDisplay() {
        etQuantity.setText(selectedQuantity.toString())
    }

    private fun addToCart() {
        if (product == null) {
            Toast.makeText(this, "Error: Producto no disponible", Toast.LENGTH_SHORT).show()
            return
        }

        val cartItem = Cartitem(
            productId = product!!.id,
            name = product!!.name,
            price = product!!.price,
            quantity = selectedQuantity,
            imageUrl = product!!.imageUrl,
            subtotal = product!!.price * selectedQuantity
        )

        if (dbHelper.addToCart(cartItem)) {
            Toast.makeText(
                this,
                "${product!!.name} agregado al carrito (${selectedQuantity} unidades)",
                Toast.LENGTH_SHORT
            ).show()

            // Volver a la lista de productos
            finish()
        } else {
            Toast.makeText(this, "Error al agregar al carrito", Toast.LENGTH_SHORT).show()
        }
    }
}