package com.example.tienda_libros.Activity

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.example.tienda_libros.R
import com.example.tienda_libros.Adapter.ProductAdapter
import com.example.tienda_libros.Database.Cartitem
import com.example.tienda_libros.Database.DatabaseHelper
import com.example.tienda_libros.Database.Product

class ProductListActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var productAdapter: ProductAdapter
    private lateinit var dbHelper: DatabaseHelper
    private lateinit var fabCart: FloatingActionButton
    private var products = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product_list)

        dbHelper = DatabaseHelper(this)
        recyclerView = findViewById(R.id.recycler_view_products)
        fabCart = findViewById(R.id.fab_cart)

        setupRecyclerView()
        loadProducts()

        fabCart.setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }
    }

    private fun setupRecyclerView() {
        recyclerView.layoutManager = LinearLayoutManager(this)
        productAdapter = ProductAdapter(
            products,
            this,
            onProductClick = { product ->
                val intent = Intent(this, ProductDetailActivity::class.java)
                intent.putExtra("product_id", product.id)
                startActivity(intent)
            },
            onAddToCart = { product ->
                addToCart(product)
            }
        )
        recyclerView.adapter = productAdapter
    }

    private fun loadProducts() {
        products = dbHelper.getAllProducts().toMutableList()
        productAdapter.notifyDataSetChanged()
    }

    private fun addToCart(product: Product) {
        val cartItem = Cartitem(
            productId = product.id,
            name = product.name,
            price = product.price,
            quantity = 1,
            imageUrl = product.imageUrl,
            subtotal = product.price
        )

        if (dbHelper.addToCart(cartItem)) {
            Toast.makeText(this, "${product.name} agregado al carrito", Toast.LENGTH_SHORT).show()
        }
    }
}