package com.example.tienda_libros.Activity

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.tienda_libros.R
import com.example.tienda_libros.Activity.ProfileActivity
import com.example.tienda_libros.Activity.RegisterActivity
import com.google.android.material.button.MaterialButton
import com.google.android.material.checkbox.MaterialCheckBox
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

class LoginActivity : AppCompatActivity() {

    private lateinit var tilEmail: TextInputLayout
    private lateinit var etEmail: TextInputEditText
    private lateinit var tilPassword: TextInputLayout
    private lateinit var etPassword: TextInputEditText
    private lateinit var cbRememberMe: MaterialCheckBox
    private lateinit var btnLogin: MaterialButton
    private lateinit var btnCreateAccount: MaterialButton

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        initViews()
        setupClickListeners()
    }

    private fun initViews() {
        tilEmail = findViewById(R.id.til_email)
        etEmail = findViewById(R.id.et_email)
        tilPassword = findViewById(R.id.til_password)
        etPassword = findViewById(R.id.et_password)
        cbRememberMe = findViewById(R.id.cb_remember_me)
        btnLogin = findViewById(R.id.btn_login)
        btnCreateAccount = findViewById(R.id.btn_create_account)
    }

    private fun setupClickListeners() {
        btnLogin.setOnClickListener {
            if (validateFields()) {
                performLogin()
            }
        }

        btnCreateAccount.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
    }

    private fun validateFields(): Boolean {
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString().trim()

        if (email.isEmpty()) {
            tilEmail.error = "El email es requerido"
            return false
        }

        if (password.isEmpty()) {
            tilPassword.error = "La contraseña es requerida"
            return false
        }

        // Limpiar errores
        tilEmail.error = null
        tilPassword.error = null

        return true
    }

    private fun performLogin() {
        // Aquí iría la lógica de autenticación
        Toast.makeText(this, "Iniciando sesión...", Toast.LENGTH_SHORT).show()

        // Simular login exitoso
        startActivity(Intent(this, ProfileActivity::class.java))
        finish()
    }
}