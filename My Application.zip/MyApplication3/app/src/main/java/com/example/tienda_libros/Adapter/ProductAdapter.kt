package com.example.tienda_libros.Adapter

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import android.widget.TextView
import android.widget.ImageView
import com.bumptech.glide.Glide
import com.example.tienda_libros.Database.Product
import com.example.tienda_libros.R

class ProductAdapter(
    private val products: List<Product>,
    private val context: Context,
    private val onProductClick: (Product) -> Unit,
    private val onAddToCart: (Product) -> Unit
) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {

    inner class ProductViewHolder(itemView: ViewGroup) : RecyclerView.ViewHolder(itemView) {
        private val tvName: TextView = itemView.findViewById(R.id.tv_product_name)
        private val tvPrice: TextView = itemView.findViewById(R.id.tv_product_price)
        private val tvStock: TextView = itemView.findViewById(R.id.tv_product_stock)
        private val btnAddCart: MaterialButton = itemView.findViewById(R.id.btn_add_to_cart)
        private val btnDetails: MaterialButton = itemView.findViewById(R.id.btn_details)
        private val ivProductImage: ImageView = itemView.findViewById(R.id.iv_product_image)

        fun bind(product: Product) {
            tvName.text = product.name
            tvPrice.text = "$${product.price}"
            tvStock.text = "Stock: ${product.stock}"

            Glide.with(context)
                .load(product.imageUrl)
                .placeholder(R.drawable.placeholder) // Imagen mientras carga
                .error(R.drawable.error) // Imagen si hay error
                .centerCrop()
                .into(ivProductImage)

            btnAddCart.setOnClickListener {
                onAddToCart(product)
            }

            btnDetails.setOnClickListener {
                onProductClick(product)
            }

            itemView.setOnClickListener {
                onProductClick(product)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.product_item, parent, false) as ViewGroup
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        holder.bind(products[position])
    }

    override fun getItemCount() = products.size
}