package com.example.tienda_libros.Database

data class Cartitem(
    val id: Int = 0,
    val productId: Int = 0,
    val name: String = "",
    val price: Double = 0.0,
    val quantity: Int = 1,
    val imageUrl: String = "",
    val subtotal: Double = 0.0
)
